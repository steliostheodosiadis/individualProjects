package com.mycompany.library.dao;

import com.mycompany.library.db.DBConnection;
import com.mycompany.library.model.Book;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    public List<Book> getAll() {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books ORDER BY id";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Book(rs.getInt("id"), rs.getString("title"), rs.getString("author"), rs.getString("category"), rs.getInt("copies")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public void add(Book b) throws SQLException {
        String sql = "INSERT INTO books(title,author,category,copies) VALUES (?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, b.getTitle()); ps.setString(2, b.getAuthor()); ps.setString(3, b.getCategory()); ps.setInt(4, b.getCopies());
            ps.executeUpdate();
        }
    }

    public void update(Book b) throws SQLException {
        String sql = "UPDATE books SET title=?, author=?, category=?, copies=? WHERE id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, b.getTitle()); ps.setString(2, b.getAuthor()); ps.setString(3, b.getCategory()); ps.setInt(4, b.getCopies()); ps.setInt(5, b.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM books WHERE id=?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) { ps.setInt(1, id); ps.executeUpdate(); }
    }

    public List<Book> searchByTitle(String q) {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE title LIKE ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "%"+q+"%"); ResultSet rs = ps.executeQuery(); while (rs.next()) { list.add(new Book(rs.getInt("id"), rs.getString("title"), rs.getString("author"), rs.getString("category"), rs.getInt("copies"))); }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
    
    public Book getById(int id) {
        String sql = "SELECT * FROM books WHERE id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Book(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("category"),
                    rs.getInt("copies")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null;
    }
}

