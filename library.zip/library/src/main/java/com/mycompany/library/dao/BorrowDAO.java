package com.mycompany.library.dao;

import com.mycompany.library.db.DBConnection;
import com.mycompany.library.model.Borrowing;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BorrowDAO {

    // create borrowing entry and decrement copies
    public void borrowBook(int userId, int bookId) throws SQLException {
        Connection c = null;
        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);

            // check copies
            try (PreparedStatement ps1 = c.prepareStatement("SELECT copies FROM books WHERE id = ? FOR UPDATE")) {
                ps1.setInt(1, bookId);
                ResultSet rs = ps1.executeQuery();
                if (!rs.next()) throw new SQLException("Book not found");
                int copies = rs.getInt("copies");
                if (copies <= 0) throw new SQLException("No copies available");
            }

            // insert borrowing
            try (PreparedStatement ps2 = c.prepareStatement("INSERT INTO borrowings(user_id,book_id) VALUES (?,?)")) {
                ps2.setInt(1, userId); ps2.setInt(2, bookId); ps2.executeUpdate();
            }

            // decrement copies
            try (PreparedStatement ps3 = c.prepareStatement("UPDATE books SET copies = copies - 1 WHERE id = ?")) {
                ps3.setInt(1, bookId); ps3.executeUpdate();
            }

            c.commit();
        } catch (SQLException ex) {
            if (c != null) try { c.rollback(); } catch (SQLException ignored) {}
            throw ex;
        } finally {
            if (c != null) try { c.setAutoCommit(true); c.close(); } catch (SQLException ignored) {}
        }
    }

    // mark returned_at and increment copies
    public void returnBook(int borrowingId) throws SQLException {
        Connection c = null;
        try {
            c = DBConnection.getConnection();
            c.setAutoCommit(false);

            int bookId;
            // get borrowing
            try (PreparedStatement ps1 = c.prepareStatement("SELECT book_id, returned_at FROM borrowings WHERE id = ? FOR UPDATE")) {
                ps1.setInt(1, borrowingId);
                ResultSet rs = ps1.executeQuery();
                if (!rs.next()) throw new SQLException("Borrowing record not found");
                if (rs.getTimestamp("returned_at") != null) throw new SQLException("Already returned");
                bookId = rs.getInt("book_id");
            }

            // set returned_at
            try (PreparedStatement ps2 = c.prepareStatement("UPDATE borrowings SET returned_at = CURRENT_TIMESTAMP WHERE id = ?")) {
                ps2.setInt(1, borrowingId); ps2.executeUpdate();
            }

            // increment copies
            try (PreparedStatement ps3 = c.prepareStatement("UPDATE books SET copies = copies + 1 WHERE id = ?")) {
                ps3.setInt(1, bookId); ps3.executeUpdate();
            }

            c.commit();
        } catch (SQLException ex) {
            if (c != null) try { c.rollback(); } catch (SQLException ignored) {}
            throw ex;
        } finally {
            if (c != null) try { c.setAutoCommit(true); c.close(); } catch (SQLException ignored) {}
        }
    }

    // list current borrowings (not yet returned)
    public List<Borrowing> getActiveBorrowingsByUser(int userId) {
        List<Borrowing> list = new ArrayList<>();
        String sql = "SELECT * FROM borrowings WHERE user_id = ? AND returned_at IS NULL ORDER BY borrowed_at DESC";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId); ResultSet rs = ps.executeQuery(); while (rs.next()) { list.add(new Borrowing(rs.getInt("id"), rs.getInt("user_id"), rs.getInt("book_id"), rs.getTimestamp("borrowed_at"), rs.getTimestamp("returned_at"))); }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // history for user
    public List<Borrowing> getBorrowingHistoryByUser(int userId) {
        List<Borrowing> list = new ArrayList<>();
        String sql = "SELECT * FROM borrowings WHERE user_id = ? ORDER BY borrowed_at DESC";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, userId); ResultSet rs = ps.executeQuery(); while (rs.next()) { list.add(new Borrowing(rs.getInt("id"), rs.getInt("user_id"), rs.getInt("book_id"), rs.getTimestamp("borrowed_at"), rs.getTimestamp("returned_at"))); }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}
