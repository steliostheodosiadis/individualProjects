package com.mycompany.library.db;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;
import java.sql.SQLException;

public class DBConnection {
    private static HikariDataSource ds;

    static {
        try {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl("jdbc:mysql://localhost:3306/librarydb?useSSL=false&serverTimezone=UTC");
            config.setUsername("root");
            config.setPassword(""); // change if you have root password
            config.setMaximumPoolSize(10);
            ds = new HikariDataSource(config);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private DBConnection() {}

    public static Connection getConnection() throws SQLException {
        return ds.getConnection();
    }
}

