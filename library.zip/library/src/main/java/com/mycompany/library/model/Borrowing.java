package com.mycompany.library.model;

import java.sql.Timestamp;

public class Borrowing {
    private int id;
    private int userId;
    private int bookId;
    private Timestamp borrowedAt;
    private Timestamp returnedAt;

    public Borrowing() {}
    public Borrowing(int id, int userId, int bookId, Timestamp borrowedAt, Timestamp returnedAt) { this.id=id; this.userId=userId; this.bookId=bookId; this.borrowedAt=borrowedAt; this.returnedAt=returnedAt; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    public Timestamp getBorrowedAt() { return borrowedAt; }
    public void setBorrowedAt(Timestamp borrowedAt) { this.borrowedAt = borrowedAt; }
    public Timestamp getReturnedAt() { return returnedAt; }
    public void setReturnedAt(Timestamp returnedAt) { this.returnedAt = returnedAt; }
}
