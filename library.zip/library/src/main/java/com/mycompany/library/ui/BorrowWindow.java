package com.mycompany.library.ui;

import com.mycompany.library.dao.BookDAO;
import com.mycompany.library.dao.BorrowDAO;
import com.mycompany.library.model.Book;
import com.mycompany.library.model.Borrowing;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class BorrowWindow extends JFrame {
    private int userId;
    private BorrowDAO borrowDAO = new BorrowDAO();
    private BookDAO bookDAO = new BookDAO();

    private DefaultTableModel availableModel;
    private DefaultTableModel activeModel;

    public BorrowWindow(int userId) {
        this.userId = userId;
        setTitle("Borrow / Return");
        setSize(900,600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));

        // Top: available books
        availableModel = new DefaultTableModel(new String[]{"ID","Title","Author","Copies"},0) { public boolean isCellEditable(int r,int c){return false;} };
        JTable availableTable = new JTable(availableModel);
        JScrollPane leftScroll = new JScrollPane(availableTable);
        leftScroll.setBorder(BorderFactory.createTitledBorder("Available Books"));

        // Right: active borrowings
        activeModel = new DefaultTableModel(new String[]{"BorrowingID","BookID","Title","BorrowedAt"},0) { public boolean isCellEditable(int r,int c){return false;} };
        JTable activeTable = new JTable(activeModel);
        JScrollPane rightScroll = new JScrollPane(activeTable);
        rightScroll.setBorder(BorderFactory.createTitledBorder("Your Active Borrowings"));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScroll, rightScroll);
        split.setDividerLocation(550);
        add(split, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER,10,10));
        JButton borrowBtn = new JButton("Borrow Selected Book");
        JButton returnBtn = new JButton("Return Selected Borrowing");
        JButton refreshBtn = new JButton("Refresh");
        buttons.add(borrowBtn); buttons.add(returnBtn); buttons.add(refreshBtn);
        add(buttons, BorderLayout.SOUTH);

        // actions
        refreshBtn.addActionListener(e -> loadData());
        borrowBtn.addActionListener(e -> {
            int row = availableTable.getSelectedRow();
            if (row==-1) { JOptionPane.showMessageDialog(this,"Select a book to borrow"); return; }
            int bookId = (int) availableModel.getValueAt(row,0);
            try { borrowDAO.borrowBook(userId, bookId); loadData(); JOptionPane.showMessageDialog(this,"Borrowed successfully"); }
            catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); }
        });

        returnBtn.addActionListener(e -> {
            int row = activeTable.getSelectedRow();
            if (row==-1) { JOptionPane.showMessageDialog(this,"Select a borrowing to return"); return; }
            int borrowingId = (int) activeModel.getValueAt(row,0);
            try { borrowDAO.returnBook(borrowingId); loadData(); JOptionPane.showMessageDialog(this,"Returned successfully"); }
            catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); }
        });

        loadData();
    }

    private void loadData() {
        // load available books
        availableModel.setRowCount(0);
        List<Book> books = bookDAO.getAll();
        for (Book b : books) if (b.getCopies() > 0) availableModel.addRow(new Object[]{b.getId(), b.getTitle(), b.getAuthor(), b.getCopies()});

        // load active borrowings for user
        activeModel.setRowCount(0);
        List<Borrowing> active = borrowDAO.getActiveBorrowingsByUser(userId);
        for (Borrowing br : active) {
            // fetch book title
            Book book = bookDAO.getById(br.getBookId());
            String title = book != null ? book.getTitle() : "(deleted)";
            activeModel.addRow(new Object[]{br.getId(), br.getBookId(), title, br.getBorrowedAt()});
        }
    }
}
