package com.mycompany.library.ui;

import com.mycompany.library.dao.UserDAO;
import com.mycompany.library.model.User;

import javax.swing.*;
import java.awt.*;

public class LoginWindow extends JFrame {
    private JTextField userField;
    private JPasswordField passField;
    private UserDAO userDAO = new UserDAO();

    public LoginWindow() {
        setTitle("Login - Library");
        setSize(350,180);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridLayout(3,2,5,5));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.add(new JLabel("Username:"));
        userField = new JTextField(); p.add(userField);
        p.add(new JLabel("Password:"));
        passField = new JPasswordField(); p.add(passField);

        JButton loginButton = new JButton("Login");
        p.add(new JLabel()); p.add(loginButton);
        add(p, BorderLayout.CENTER);

        loginButton.addActionListener(e -> doLogin());
    }

    private void doLogin() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword());
        User u = userDAO.findByUsernameAndPassword(username, password);
        if (u != null) {
            SwingUtilities.invokeLater(() -> {
                new MainWindow(u).setVisible(true);
            });
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

