package com.mycompany.library.ui;

import com.mycompany.library.dao.BookDAO;
import com.mycompany.library.model.Book;
import com.mycompany.library.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class MainWindow extends JFrame {
    private User currentUser;
    private BookDAO bookDAO = new BookDAO();

    private DefaultTableModel tableModel;
    private JTable table;

    private JTextField titleField, authorField, categoryField, copiesField, searchField;
    private JButton addBtn, updateBtn, deleteBtn, borrowBtn, refreshBtn, searchBtn;

    public MainWindow(User user) {
        this.currentUser = user;
        setTitle("Library - Main ("+user.getUsername()+" : "+user.getRole()+")");
        setSize(1000,700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10,10));

        // top form
        JPanel form = new JPanel(new GridLayout(2,5,5,5));
        form.setBorder(BorderFactory.createTitledBorder("Book Form"));
        titleField = new JTextField(); authorField = new JTextField(); categoryField = new JTextField(); copiesField = new JTextField();
        form.add(new JLabel("Title:")); form.add(titleField);
        form.add(new JLabel("Author:")); form.add(authorField);
        form.add(new JLabel("Category:")); form.add(categoryField);
        form.add(new JLabel("Copies:")); form.add(copiesField);

        addBtn = new JButton("Add"); updateBtn = new JButton("Update"); deleteBtn = new JButton("Delete");
        borrowBtn = new JButton("Borrow/Return"); refreshBtn = new JButton("Refresh");
        form.add(addBtn); form.add(updateBtn);

        add(form, BorderLayout.NORTH);

        // search
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search"));
        searchField = new JTextField(30); searchBtn = new JButton("Search");
        searchPanel.add(new JLabel("Title contains:")); searchPanel.add(searchField); searchPanel.add(searchBtn); searchPanel.add(refreshBtn); searchPanel.add(borrowBtn);
        add(searchPanel, BorderLayout.SOUTH);

        tableModel = new DefaultTableModel(new String[]{"ID","Title","Author","Category","Copies"},0) { public boolean isCellEditable(int r,int c){return false;} };
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // role-based UI: if user is not admin, disable add/update/delete
        if (!"admin".equalsIgnoreCase(currentUser.getRole())) {
            addBtn.setEnabled(false); updateBtn.setEnabled(false); deleteBtn.setEnabled(false);
        }

        // actions
        addBtn.addActionListener(e -> onAdd());
        updateBtn.addActionListener(e -> onUpdate());
        deleteBtn.addActionListener(e -> onDelete());
        refreshBtn.addActionListener(e -> loadAll());
        searchBtn.addActionListener(e -> onSearch());
        borrowBtn.addActionListener(e -> new BorrowWindow(currentUser.getId()).setVisible(true));

        table.addMouseListener(new MouseAdapter(){ public void mouseClicked(MouseEvent e){ if (e.getClickCount()==2) loadSelectedToForm(); } });

        loadAll();
    }

    private void loadAll(){
        tableModel.setRowCount(0);
        List<Book> list = bookDAO.getAll();
        for (Book b : list) tableModel.addRow(new Object[]{b.getId(), b.getTitle(), b.getAuthor(), b.getCategory(), b.getCopies()});
    }

    private void onAdd(){
        try {
            String title = titleField.getText().trim(); String author = authorField.getText().trim(); String category = categoryField.getText().trim(); int copies = Integer.parseInt(copiesField.getText().trim());
            bookDAO.add(new Book(title,author,category,copies)); loadAll(); clearForm();
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); }
    }

    private void onUpdate(){
        int row = table.getSelectedRow(); if (row==-1){ JOptionPane.showMessageDialog(this,"Select a row"); return; }
        try {
            int id = (int) table.getValueAt(row,0);
            String title = titleField.getText().trim(); String author = authorField.getText().trim(); String category = categoryField.getText().trim(); int copies = Integer.parseInt(copiesField.getText().trim());
            bookDAO.update(new Book(id,title,author,category,copies)); loadAll(); clearForm();
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); }
    }

    private void onDelete(){
        int row = table.getSelectedRow(); if (row==-1){ JOptionPane.showMessageDialog(this,"Select a row"); return; }
        int id = (int) table.getValueAt(row,0); int ok = JOptionPane.showConfirmDialog(this,"Delete book?","Confirm",JOptionPane.YES_NO_OPTION); if (ok==JOptionPane.YES_OPTION) { try { bookDAO.delete(id); loadAll(); clearForm(); } catch(Exception ex){ JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); } }
    }

    private void onSearch(){ String q = searchField.getText().trim(); if (q.isEmpty()) { loadAll(); return; } tableModel.setRowCount(0); for (Book b : bookDAO.searchByTitle(q)) tableModel.addRow(new Object[]{b.getId(), b.getTitle(), b.getAuthor(), b.getCategory(), b.getCopies()}); }

    private void loadSelectedToForm(){ int row = table.getSelectedRow(); if (row==-1) return; titleField.setText((String) table.getValueAt(row,1)); authorField.setText((String) table.getValueAt(row,2)); categoryField.setText((String) table.getValueAt(row,3)); copiesField.setText(String.valueOf(table.getValueAt(row,4))); }

    private void clearForm(){ titleField.setText(""); authorField.setText(""); categoryField.setText(""); copiesField.setText(""); }
}

