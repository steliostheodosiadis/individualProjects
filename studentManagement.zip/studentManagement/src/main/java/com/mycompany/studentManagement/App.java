package com.mycompany.studentManagement;

import com.mycompany.studentManagement.ui.LoginWindow;

import javax.swing.*;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginWindow().setVisible(true);
        });
    }
}