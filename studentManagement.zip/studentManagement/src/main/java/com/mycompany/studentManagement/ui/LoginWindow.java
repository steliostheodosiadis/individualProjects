package com.mycompany.studentManagement.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginWindow extends JFrame {
    private JTextField userField;
    private JPasswordField passField;

    public LoginWindow() {
        setTitle("Login");
        setSize(300,180);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridLayout(3,2,5,5));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.add(new JLabel("Username:"));
        userField = new JTextField(); p.add(userField);
        p.add(new JLabel("Password:"));
        passField = new JPasswordField(); p.add(passField);

        JButton loginButton = new JButton("Login");
        p.add(new JLabel()); p.add(loginButton);

        add(p, BorderLayout.CENTER);

        loginButton.addActionListener(e -> doLogin());
    }

    private void doLogin() {
        String user = userField.getText();
        String pass = new String(passField.getPassword());

        // Very simple check against users table (no hashing) - for demo only
        try (Connection c = com.mycompany.studentManagement.db.DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")) {
            ps.setString(1, user);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // success
                SwingUtilities.invokeLater(() -> {
                    new MainWindow().setVisible(true);
                });
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
