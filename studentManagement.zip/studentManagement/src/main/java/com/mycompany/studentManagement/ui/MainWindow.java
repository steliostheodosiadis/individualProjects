package com.mycompany.studentManagement.ui;

import com.mycompany.studentManagement.dao.StudentDAO;
import com.mycompany.studentManagement.model.Student;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class MainWindow extends JFrame {
    private JTextField nameField, emailField, ageField, searchField;
    private JButton addButton, updateButton, deleteButton, refreshButton, searchButton;
    private JTable table;
    private DefaultTableModel tableModel;
    private StudentDAO dao = new StudentDAO();

    public MainWindow() {
        setTitle("Student Management");
        setSize(800,600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));

        JPanel top = new JPanel(new BorderLayout(5,5));
        JPanel form = new JPanel(new GridLayout(2,4,5,5));
        form.setBorder(BorderFactory.createTitledBorder("Student Form"));

        nameField = new JTextField(); emailField = new JTextField(); ageField = new JTextField();
        form.add(new JLabel("Name:")); form.add(nameField);
        form.add(new JLabel("Email:")); form.add(emailField);
        form.add(new JLabel("Age:")); form.add(ageField);

        addButton = new JButton("Add"); updateButton = new JButton("Update"); deleteButton = new JButton("Delete"); refreshButton = new JButton("Refresh");
        form.add(addButton); form.add(updateButton);

        top.add(form, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search / Filter"));
        searchField = new JTextField(20); searchButton = new JButton("Search");
        searchPanel.add(new JLabel("Name contains:")); searchPanel.add(searchField); searchPanel.add(searchButton); searchPanel.add(refreshButton); searchPanel.add(deleteButton);
        top.add(searchPanel, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID","Name","Email","Age"},0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(new JLabel("Double-click a row to load into form"));
        add(bottom, BorderLayout.SOUTH);

        // Actions
        addButton.addActionListener(e -> onAdd());
        updateButton.addActionListener(e -> onUpdate());
        deleteButton.addActionListener(e -> onDelete());
        refreshButton.addActionListener(e -> loadAll());
        searchButton.addActionListener(e -> onSearch());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) loadSelectedToForm();
            }
        });

        loadAll();
    }

    private void loadAll() {
        tableModel.setRowCount(0);
        List<Student> list = dao.getAll();
        for (Student s : list) tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(), s.getAge()});
    }

    private void onAdd() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String ageT = ageField.getText().trim();
        if (name.isEmpty() || email.isEmpty() || ageT.isEmpty()) { JOptionPane.showMessageDialog(this, "Fill all fields"); return; }
        try {
            int age = Integer.parseInt(ageT);
            dao.add(new Student(name,email,age));
            loadAll(); clearForm();
        } catch (NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Age must be a number"); }
        catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); ex.printStackTrace(); }
    }

    private void onUpdate() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a row to update"); return; }
        int id = (int) tableModel.getValueAt(row,0);
        try {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            int age = Integer.parseInt(ageField.getText().trim());
            Student s = new Student(id,name,email,age);
            dao.update(s);
            loadAll(); clearForm();
        } catch (NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Age must be a number"); }
        catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); ex.printStackTrace(); }
    }

    private void onDelete() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a row to delete"); return; }
        int id = (int) tableModel.getValueAt(row,0);
        int ok = JOptionPane.showConfirmDialog(this, "Delete selected student?","Confirm",JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            try { dao.delete(id); loadAll(); clearForm(); } catch (Exception ex) { ex.printStackTrace(); }
        }
    }

    private void onSearch() {
        String q = searchField.getText().trim();
        if (q.isEmpty()) { loadAll(); return; }
        tableModel.setRowCount(0);
        for (Student s : dao.searchByName(q)) tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(), s.getAge()});
    }

    private void loadSelectedToForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;
        nameField.setText((String) tableModel.getValueAt(row,1));
        emailField.setText((String) tableModel.getValueAt(row,2));
        ageField.setText(String.valueOf(tableModel.getValueAt(row,3)));
    }

    private void clearForm() { nameField.setText(""); emailField.setText(""); ageField.setText(""); }
}

