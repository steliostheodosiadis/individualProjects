const songImage = document.getElementById("song-image");
const songName = document.getElementById("song-name");
const songArtist = document.getElementById("song-artist");

const songSlider = document.getElementById("slider-song");

const playpauseButton = document.getElementById("playpause-song");
const prevSongButton = document.getElementById("prev-song");
const nextSongButton = document.getElementById("next-song");

const songs = [
    {
        image: "./album-art1.jpg",
        name: "Deck The Halls",
        artist: "John Parry",
        audio: "./deck-the-halls.mp3"
    },
    {
        image: "./album-art2.jpg",
        name: "Jingle Bells",
        artist: "James Lord Pierpont",
        audio: "./jingle-bells.mp3"
    },
    {
        image: "./album-art3.jpg",
        name: "Joy To The World",
        artist: "Isaac Watts",
        audio: "./joy-to-the-world.mp3",
    },
];

const audio = document.createElement("audio");
let currentSongIndex = 0;
updateSong();

prevSongButton.addEventListener("click", function() {
    if(currentSongIndex==0) {
        return;
    }
    currentSongIndex--;
    updateSong();
});

nextSongButton.addEventListener("click", function() {
    if(currentSongIndex==songs.length - 1) {
        currentSongIndex = 0;
    }
    else {
        currentSongIndex++;
    }
    updateSong();
});

playpauseButton.addEventListener("click", function() {
    if(!audio.paused) {
        audio.pause();
    }
    else {
        audio.play();
    }
});

function updatePlayPauseIcon() {
    if (audio.paused) {
        playpauseButton.className = "fa-solid fa-circle-play fa-3x";
    } else {
        playpauseButton.className = "fa-solid fa-circle-pause fa-3x";
    }
}

audio.addEventListener("play", updatePlayPauseIcon);
audio.addEventListener("pause", updatePlayPauseIcon);

function updateSong() {
    const song = songs[currentSongIndex];
    songImage.src = song.image;
    songName.innerText = song.name;
    songArtist.innerText = song.artist;
    
    audio.src = song.audio;

    audio.onloadedmetadata = function() {
        songSlider.value = 0;
        songSlider.max = audio.duration;
    }
    updatePlayPauseIcon();
}

songSlider.addEventListener("change", function() {
    audio.currentTime = songSlider.value;
})

audio.addEventListener("timeupdate", function () {
    songSlider.value = audio.currentTime;
});

const repeatSong = document.getElementById("repeat-song");
let isRepeat = false;

repeatSong.addEventListener("click", function() {
    isRepeat = !isRepeat;
    repeatSong.style.color = isRepeat ? "red" : "black";
});

const shuffleSong = document.getElementById("shuffle-song");
let isShuffle = false;

shuffleSong.addEventListener("click", function () {
    isShuffle = !isShuffle;
    shuffleSong.style.color = isShuffle ? "red" : "black";
});

audio.addEventListener("ended", function () {

    if (isRepeat) {
        audio.currentTime = 0;
        audio.play();
        return;
    }

    if (isShuffle) {
        let randomIndex;
        do {
            randomIndex = Math.floor(Math.random() * songs.length);
        } while (randomIndex === currentSongIndex);

        currentSongIndex = randomIndex;
    } else {
        currentSongIndex =
            (currentSongIndex + 1) % songs.length;
    }

    updateSong();
});